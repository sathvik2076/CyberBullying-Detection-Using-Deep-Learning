const express = require('express');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const session = require('express-session');
const app = express();

// In-memory storage for demonstration; use a database in production
const users = [];

app.use(bodyParser.urlencoded({ extended: false }));
app.use(session({ secret: 'your-secret', resave: false, saveUninitialized: true }));

app.post('/signup', (req, res) => {
  const { username, password } = req.body;
  const hashedPassword = bcrypt.hashSync(password, 10);
  users.push({ username, password: hashedPassword });
  res.redirect('/login'); // Redirect to login page
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username);
  
  if (user && bcrypt.compareSync(password, user.password)) {
    req.session.user = user;
    res.redirect('/dashboard'); // Redirect to dashboard page
  } else {
    res.redirect('/login'); // Redirect back to login on failure
  }
});

app.listen(3000, () => console.log('Server running on port 3000'));
