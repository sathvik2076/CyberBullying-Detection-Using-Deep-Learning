function updateSettings() {
    const oldPassword = document.getElementById('old-password').value;
    const newPasswordField = document.getElementById('new-password');
  
    // Predefined correct old password (this should be securely handled in a real application)
    const correctOldPassword = "CorrectOldPassword"; // Replace with actual password check
  
    // Check if the old password is correct
    if (oldPassword === correctOldPassword) {
      newPasswordField.disabled = false; // Enable the new password input
    } else {
      alert("Old password is incorrect!"); // Alert the user
      newPasswordField.disabled = true; // Keep the new password field disabled
      return; // Stop execution if the old password is incorrect
    }
  
    // Logic to handle updates goes here (e.g., saving new username, email, etc.)
    // For demonstration, we'll just show a notification.
    
    // If the new password is not empty, show the notification
    if (newPasswordField.value.trim() !== "") {
      const notificationMessage = document.getElementById('notification-message');
      notificationMessage.style.display = 'block'; // Show the notification
  
      // Hide the notification after 3 seconds
      setTimeout(() => {
        notificationMessage.style.display = 'none';
      }, 3000);
    } else {
      alert("Please enter a new password!"); // Alert if no new password is entered
    }
  }
  