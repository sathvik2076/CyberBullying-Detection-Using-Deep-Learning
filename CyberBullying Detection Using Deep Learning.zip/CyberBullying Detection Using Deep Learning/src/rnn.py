import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense, SpatialDropout1D

# Load preprocessed data
X_train = np.load('X_train.npy')
X_test = np.load('X_test.npy')
y_train = np.load('y_train.npy')
y_test = np.load('y_test.npy')

# Define the RNN model
model_rnn = Sequential([
    Embedding(5000, 100, input_length=100),
    SpatialDropout1D(0.2),
    LSTM(100, dropout=0.2, recurrent_dropout=0.2),
    Dense(1, activation='sigmoid')
])

model_rnn.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
model_rnn.summary()

# Train the RNN model
history_rnn = model_rnn.fit(X_train, y_train, epochs=5, batch_size=4, validation_data=(X_test, y_test))

# Save the model
model_rnn.save('rnn_cyberbullying_model.h5')
print("RNN model saved.")
